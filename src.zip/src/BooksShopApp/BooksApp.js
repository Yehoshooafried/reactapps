import React, { Component } from 'react';
import ReactDOM from 'react-dom/client';
import Book from './component/book';
// import logo from './logo.svg';
// import './App.css';
import "./component/styles.css"
import './component/styles.css'

//book constructor
class AddBook {
  constructor(id, title, author, likes, onshelf, sample, clickHandler, likeButton) {
    this.id = id;
    this.title = title;
    this.author = author;
    this.likes = likes;
    this.onshelf = onshelf;
    this.sample = sample;
    this.clickHandler = clickHandler;
    this.likeButton = likeButton
  }

}


//appp component
class BooksApp extends Component {
  constructor(props) {
    super(props);



    this.state = {
      booksArr: [
        new AddBook(0, 'test1', 'b', 0, true, 'בראשית ברא', this.clickHandler, this.likeButton),
        new AddBook(0, 'test2', 'b', 0, true, 'בראשית ברא', this.clickHandler, this.likeButton),
        new AddBook(0, 'test3', 'b', 0, true, ' ברא', this.clickHandler, this.likeButton),
        new AddBook(0, 'test4', 'b', 0, true, 'בראשית ברא', this.clickHandler, this.likeButton),
        { id: 0, title: 'mikra', author: "text1", likes: 0, onshelf: true, sample: 'בראשית ברא' },
        { id: 1, title: 'mishna', author: "text2", likes: 1, onshelf: true, sample: " מאימתי קורין", },
        { id: 2, title: 'halacha', author: "text3", likes: 1, onshelf: true, sample: ' שיויתי ה לנגדי תמיד', },
      ]
    }


    //binding this to the component eathar the button
    this.takeButton = this.takeButton.bind(this);
    this.clickHandler = this.clickHandler.bind(this);
    this.likeButton = this.likeButton.bind(this);
  }

//methods
  takeButton(x) {
    let ba = this.state.booksArr;
    ba[x].onshelf = false;
    this.setState(ba)
  }

  likeButton(x) {
    let ba = this.state.booksArr;
    ba[x].likes += 1;
    this.setState({ ba })
  }

  clickHandler(x) {
    alert(this.state.booksArr[x].sample)
  }


  render() {
    return (
      <div >
               <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">my Books shop</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#!">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Shop</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#!">All Products</a></li>
                                <li><hr class="dropdown-divider" /></li>
                                <li><a class="dropdown-item" href="#!">Popular Items</a></li>
                                <li><a class="dropdown-item" href="#!">New Arrivals</a></li>
                            </ul>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <button class="btn btn-outline-dark" type="submit">
                            <i class="bi-cart-fill me-1"></i>
                            Cart
                            <span class="badge bg-dark text-white ms-1 rounded-pill">0</span>
                        </button>
                    </form>
                </div>
            </div>
        </nav>
        <section className='py-5' >
          <div className='container px-4 px-lg-5 mt-5'>
            <div className='row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center'>
          {this.state.booksArr.map((e, index) =><div className='col mb-5'  key={index}>  <Book data={e}  x={index}
            takeButton={this.takeButton} clickHandler={this.clickHandler} likeButton={this.likeButton} /></div>)}
       </div>
       </div>
        </section>
      </div>
    );
  }

}

export default BooksApp;
