import React from "react";
import { ReactDOM } from "react";

class Player extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            styles: {
                height: '300',
                border: '1px solid black'

            }

        }
    }

    render() {
        return (
        <div style={this.state.styles} className="playerDiv">
            <h1>{this.props.playerName}</h1>
            <h3 id={this.props.id} >steps:{this.props.steps}</h3>
            <h3 id={this.props.id} >scores:{this.props.scores}</h3>
            <button id={this.props.id} onClick={this.props.adder}>add 1</button>
            <button id={this.props.id} onClick={this.props.adder}>reduce 1</button>
            <button id={this.props.id} onClick={this.props.adder}>multiply by 2</button>
            <button id={this.props.id} onClick={this.props.adder}>Divide by 2</button>
            <h3>the current number:{this.props.theNumber}</h3>
        </div>

        );
    }
}

export default Player;