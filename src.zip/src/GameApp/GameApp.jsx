import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Player from './component/Player';
class GameApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            players:
                [
                    { number: Math.floor(Math.random() * 100), steps: 0, scores: "" },
                    { number: Math.floor(Math.random() * 100), steps: 0, scores: "" }
                ],
                header:<div> <button >add player</button> <button >add player</button></div>,


        }
        this.counter = this.counter.bind(this)
    }


    counter(e) {
        let playerNo = e.target.id
        let buttonType = e.target.innerText
        console.log(this.state);

        let a;

        switch (buttonType) {
            case 'add 1':
                a = [...this.state.players];
                a[playerNo].number += 1;
                a[playerNo].steps++;
                this.setState({
                    players: a
                })
                break;
            case 'reduce 1':
                a = [...this.state.players];
                a[playerNo].number -= 1
                a[playerNo].steps++
                this.setState({
                    players: a
                })
                break;
            case 'multiply by 2':
                a = [...this.state.players];
                a[playerNo].number *= 2
                a[playerNo].steps++
                this.setState({
                    players: a
                })
                break;
            case 'Divide by 2':
                a = [...this.state.players];
                a[playerNo].number /= 2
                a[playerNo].steps++
                this.setState({
                    players: a
                })
                break;
            default:
                break;
        }



        setTimeout(() => {
            if (this.state.players[playerNo].number == 100) {
                a = [...this.state.players];
                a[playerNo].number = Math.floor(Math.random() * 100)

                setTimeout(() => {
                    a[playerNo].scores += this.state.players[playerNo].steps + ','
                    console.log(this.state.players[playerNo].steps);
                }, 0);

                a[playerNo].steps = 0
                this.setState({
                    players: a
                })

            }
        }, 0);


    }


    render() {
        return (
            <div>
                <h1 style={{ height: '300', border: '1px solid black'}}>game app{this.state.header}</h1>
                
                {this.state.players.map(((e, index) => {
                    return <Player key={index} scores={e.scores}
                        steps={e.steps} id={index} adder={this.counter} playerName={'222'}
                        theNumber={e.number} />
                }))}


            </div>

        );
    }
}

export default GameApp;