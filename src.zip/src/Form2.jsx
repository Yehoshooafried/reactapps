import React, { Component } from "react"

/**
 * Challenge: Wire up the partially-finished travel form so that it works!
 * Remember to use the concept of controlled forms
 * https://reactjs.org/docs/forms.html
 * 
 * All information should be populating the text below the form in real-time
 * as you're filling it out
 * 
 * This exercise is adapted from the V School curriculum on vanilla JS forms:
 * https://coursework.vschool.io/travel-form/
 * 
 * All of our challenges and learning resources are open for the public
 * to play around with and learn from at https://coursework.vschool.io
 */

class AppForm extends React.Component {
    constructor() {
        super()
        this.state = {
            firstName: '',
            lastName: '',
            age: '',
            isChecked: '',
            selected: '',
            gender: '',
            isVegan: false,
            isKosher: false,
            isLactoseFree: false
        }
        this.hadleChange = this.hadleChange.bind(this)
    }
    hadleChange(event) {
        const name = event.target.name
        const value = event.target.value
        this.setState({ [name]: value })

    }
    render() {
        return (
            <main>
                <form>
                    <input name='firstName'
                        value={this.state.firstName}
                        onChange={this.hadleChange}
                    /><br />

                    <input
                        placeholder="Last Name"
                        name="lastName"
                        value={this.state.lastName}
                        onChange={this.hadleChange}
                    /><br />
                    <input
                        name='age'
                        placeholder="Age"
                        value={this.state.age}
                        onChange={this.hadleChange}
                    /><br />
                    <label htmlFor="">
                        <input
                            type="radio"
                            name="gender"
                            value='male'
                            checked={this.state.gender === 'male'}
                            onChange={this.hadleChange}
                        />male <br />
                        <input
                            checked={this.state.gender === 'female'}
                            type="radio"
                            name="gender"
                            value='female'
                            onChange={this.hadleChange}
                        />female
                    </label>
                    <br />
                    <select name="selected" value={this.state.selected} onChange={this.hadleChange}>
                        <option value="us">us</option>
                        <option value="uk">uk</option>
                        <option value="china">china</option>
                    </select>
                    <br />
                    <label >kosher?
                        <input
                         type="checkbox"
                         name="isKosher"
                         onChange={this.hadleChange}
                         checked={this.state.isKosher}
                         />
                    </label><br />
                    <label >is vegan?
                        <input
                         type="checkbox"
                         name="isVegan"
                         onChange={this.hadleChange}
                         checked={this.state.isVegan}
                         />
                    </label><br />
                    <label >is lacost free?
                        <input
                         type="checkbox"
                         name="isLactoseFree"
                         onChange={this.hadleChange}
                         checked={this.state.isLactoseFree}
                         />
                    </label>
                    <br />

                    <button>Submit</button>
                </form>
                <hr />
                <h2>Entered information:</h2>
                <p>Your name: {`${this.state.firstName} ${this.state.lastName}`}</p>
                <p>Your age: {this.state.age}</p>
                <p>Your gender: {this.state.selected}</p>
                <p>Your destination: {this.state.gender}</p>
                <p>
                    Your dietary restrictions: <br />
                    kosher:{this.state.isKosher? 'yes':'no'} <br />
                    vegan:{this.state.isVegan? 'yes':'no' } <br />
                    glotan free:{this.state.isLactoseFree? 'yes':'no'}
                </p>
            </main>
        )
    }
}

export default AppForm
