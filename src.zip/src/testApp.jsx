import React from "react";
import { ReactDOM } from "react";
// class Form extends React.Component {
//     constructor(props) {
//         super(props);
//         let x = 9
//      this.state = { isToggleOn: 1 };


//       this.handleClick = this.handleClick.bind(this)  
//     }
    
//     handleClick(){ 
//         this.setState(t =>({
//             isToggleOn: 14 
//         }))
//     }
//     render() { 
//         return ( <button onClick={this.handleClick}>
//         {this.state.isToggleOn }
//         </button>);
//     }

// }
    function Form() {
        const shoot = (b) => {
          console.log(b);
              /*
              'b' represents the React event that triggered the function.
          In this case, the 'click' event
              */
        }
      
        return (
          <button  onWheel={(t) => shoot(t)}>Take the shot!</button>
        );
      }
      
    //   const root = ReactDOM.createRoot(document.getElementById('root'));
    //   root.render(<Football />);

 
export default Form;

