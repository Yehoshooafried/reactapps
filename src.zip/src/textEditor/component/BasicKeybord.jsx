import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class BasicKeybord extends React.Component {
    constructor(props) {
        super(props);

        this.changeKeybordButton = this.changeKeybordButton.bind(this)
        this.LanguagegKeys = ['upercase', 'english', 'עברית']
        this.colorButton = ['red', 'green', 'black']
        this.special = ['undo', 'delete', 'clear','to lower case', 'TO UPEPER CASE']
        this.sizes = [30, 40, 50]


        this.space = "space";

        this.letters = {
            layouts: {
                abc: [['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
                ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
                ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
                ["z", "x", "c", "v", "b", "n", "m", "space"]
                ],
                alfaBeta: [
                    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
                    ['/', "'", 'ק', 'ר', 'א', 'ט', 'ו', 'ן', 'ם', 'פ'],
                    ['ש', 'ד', 'ג', 'כ', 'ע', 'י', 'ח', 'ל', 'ך', 'ף'],
                    ['ז', 'ס', 'ב', 'ה', 'נ', 'מ', 'צ', 'ת', 'ץ', '.', 'space']
                ],
                upercase: [["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"],
                ["K", "L", "M", "N", "O", "P", "Q", "R", "S", "T"],
                ["U", "V", "W", "X", "Y", "Z", 'space']]
            }
        }
    }

    state = {
        layout: [['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
        ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
        ["z", "x", "c", "v", "b", "n", "m", "space"]
        ],
        style: { color: 'black' }
    }

    changeKeybordButton(e) {
        console.log(this.letters.layouts.upercase);
        switch (e.target.id) {
            case 'עברית': this.setState({ layout: this.letters.layouts.alfaBeta })
                break;
            case 'english': this.setState({ layout: this.letters.layouts.abc })
                break;
            case 'upercase': this.setState({ layout: this.letters.layouts.upercase })
                break;
        }

    }

    render() {
        return (
            <div>
                {this.state.layout.map((b, index) => { return <div key={index}>{b.map((e, index) => { return <button id={e} onClick={this.props.writeButton} key={index}>{e} </button> })}</div> })}
                <h3>language</h3>
                {this.LanguagegKeys.map(((e, index) => { return <button id={e} onClick={this.changeKeybordButton} key={index}>{e} </button> }))}
                <h3>color</h3>
                {this.colorButton.map(((e, index) => { return <button onClick={this.props.changeColor} id={e} key={index}>{e}</button> }))}
                <h3>fontSize</h3>
                {this.sizes.map(((e, index) => { return <button id={e} onClick={this.props.changeSize} key={index}>{e}</button> }))}
                <h3>special</h3>
                {this.special.map(((e,index) => {return <button id={e} onClick={this.props.special} key={index} >{e}</button >}))}
            </div>

        )
    };
};



export default BasicKeybord;
