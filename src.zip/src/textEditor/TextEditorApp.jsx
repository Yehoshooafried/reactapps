import React, { Component } from 'react'
import ReactDOM from 'react-dom';
import BasicKeybord from './component/BasicKeybord';
class TextEditorApp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            text: [],
            styles: {
                color: 'red',
                fontSize: '30px'
                , divStyles: {
                    height: '100px',
                    border: '1px solid black'
                }
            }

        }


        this.writeButton = this.writeButton.bind(this);
        this.changeSize = this.changeSize.bind(this);
        this.special = this.special.bind(this);
        this.changeColor = this.changeColor.bind(this);
    }


    writeButton(e) {
        let id = e.target.id === 'space' ? '  ' : e.target.id
        let newText = <span style={this.state.styles}>{id}</span>
        this.setState({ text: [...this.state.text, newText] })
        console.log(id);
    }

    changeColor(e) {
        let color = e.target.id
        this.setState({

            styles: {
                ...this.state.styles,
                color: color,
            }
        })
    }

    changeSize(e) {
        let size = e.target.id
        this.setState({
            styles: {
                ...this.state.styles,
                fontSize: `${size}px`
            }
        })
    }

    special(e) {
        let target = e.target.id
        switch (target) {
            case "undo": console.log(target);
                break;

            case "delete": console.log(target)
                this.setState({ text: [...this.state.text.slice(0, -1)] });
                break;

            case "clear": console.log(target)
                this.setState({ text: "" });
                break;

            case 'to lower case':
                {
                   
                    let toString = this.state.text.map(((e,index) => { return <span key={index} style={e.props.style}>{e.props.children.toLowerCase()}</span>}));
                    
                    // let withSpan = toLowerCase.map(((e)=>{return <span style={this.state.styles}>{e}</span> }))
                    this.setState({ text: [...toString] });
                }
                break;

            case 'TO UPEPER CASE': 
                {
                    // let text = ''
                    let toString = this.state.text.map(((e,index) => { return <span key={index} style={e.props.style}>{e.props.children.toUpperCase()}</span>}));
                    // let toUpperCase = text.toUpperCase()
                    // let withSpan = toLowerCase.map(((e)=>{return <span style={this.state.styles}>{e}</span> }))
                    this.setState({ text: [...toString] });
                }



                break;
        }
    }


    render() {
        return (
            <div>
                <p style={this.state.styles.divStyles}>{this.state.text}</p>
                <BasicKeybord special={this.special} changeSize={this.changeSize} writeButton={this.writeButton} changeColor={this.changeColor} />
            </div>
        );
    }
}

export default TextEditorApp;