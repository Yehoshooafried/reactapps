import React, { Component } from 'react';

class Form extends Component {
    constructor(props) {
        super(props);
        this.state = {
            nameVal: '',
            emailVal: 'email',
            checkBox : false
        }
    }
    valurHandle = (e) => {

        this.setState({ nameVal: e.target.value })
    }
    submitHandler(e){
        e.preventDefault()
        console.log();
    }
    render() {
        return (
            <form onSubmit={this.submitHandler}>
                <label htmlFor="">name</label>
                <div><input
                 onChange={this.valurHandle}
                  value={this.state.nameVal} 
                  />

                    {this.state.nameVal.length > 8 && <div>required min 8</div>}</div>

                <textarea value={'text'} name="" id="" cols="30" rows="10"></textarea>
                <div>
                    <select value={1}>
                        <option value="">1</option>
                        <option value="">2</option>
                        <option value="">3</option>
                        <option value="">4</option>
                    </select>
                </div>
                <input type='checkBox'  onChange={()=>{this.setState({checkBox: !this.state.checkBox})}} checked={this.state.checkBox}/>
                <input type="file" />
                <div>
                   
                </div>
<button type='submit'>submit</button>            </form>
        );
    }
}

export default Form;