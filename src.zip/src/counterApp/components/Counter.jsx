import React from "react";
import { ReactDOM } from "react";

class Counter extends React.Component {
    constructor(props) {
        super(props);
   this.state = { inc: 0 } 
}


    increment(){
this.setState((state,props)=>{return{inc:this.state.inc+this.props.count}})
    }

    decrement(){     
this.setState((state,props)=>{return{inc:this.state.inc-this.props.count}})
    }

    reset(){
this.setState((state,props)=>{return{inc:0}})
    }

    render() { 
        return ( <div>
            <button onClick={()=>this.increment()}>INC</button>
            <button onClick={()=>this.decrement()}>DEC</button>
            <button onClick={()=>this.reset()}>RES</button>
            <h4>counter {this.props.count}now is:{this.state.inc}</h4>
        </div> );
    }
}
 
export default Counter;