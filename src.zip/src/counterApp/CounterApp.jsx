import React from "react";
import { ReactDOM } from "react";
import Counter from "./components/Counter";
const arr = [1,2,3,4,5]
class CounterApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    render(){
return (
<div>
{/* <span>counter 1<Counter count={1}/></span>
<span>counter 1<Counter count={1}/></span>
<span>counter 1<Counter count={1}/></span> */}

{arr.map(( e,index) =><span key={index} ><br /> counter{index+1}<Counter count ={index+1}/></span> )}
</div>



)


    }

    
}


// {return {{
//    (<div>
//            
//         </div>
//         );
//     }
export default CounterApp;