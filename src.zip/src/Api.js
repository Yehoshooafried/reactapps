// import React from "react";
// import { ReactDOM } from "react-dom/client";

// class Api extends React.Component{
//     constructor(props) {
//         super(props);
//         this.state = { 
//             loading: false,
//             character: {}
//         } 
//     }
//     componentDidMount(){
//       this.setState({loading:false})
//       fetch("https://swapi.dev/api/people/5/")
//       .then(response => response.json())
//       .then(data => {
//         this.setState({
//             loading:false,
//             character: data
//         })
//       })

//     }
//     render() {
//         const text = this.state.loading ? "loading..." : this.state.character.name
//         return (
//             <div>
//                 <p>{text}</p>
//             </div>
//         )
//     }
// }
 
// export default Api;

