import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';
// import App from './App';
import GameApp from './GameApp/GameApp';
import TextEditorApp from './textEditor/TextEditorApp';
import BooksApp from './BooksShopApp/BooksApp';
// import Form from './testApp';
import CounterApp from './counterApp/CounterApp';
import NumKeyApp from './numKeyApp/NumKeyApp';
// import Clock from './Clock';
import Api from './Api';
import Form from './Form';
import AppForm from './Form2';
import AllClocks from './watches/AllClocks';
import Ref from './Ref';
import GeneratorApp from './generator/GeneratorApp';
import './style.css'
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <React.Fragment>
    <Form/>
    </React.Fragment>
);

// setInterval(() => root.render(<App/>),1000)

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
