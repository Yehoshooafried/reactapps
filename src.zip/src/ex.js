function timer(time) {
    return new Promise((res, rej) => {
        const isError = false;
        setTimeout(() => {
            isError ?
                rej('Error') :
                res(time / 1000);
        }, time)

    })

}
function printTimer() {
    timer(1000).then(res => console.log(res));
    timer(2000).then(res => console.log(res));
    return 'finshed'
}

//   printTimer().then(res => console.log(res));

