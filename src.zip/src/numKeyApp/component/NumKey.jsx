import React from "react";
import { ReactDOM } from "react";

class NumKey extends React.Component {
    constructor(props) {
        super(props);
    this.state = {}
}
    
    render() {
        return (<div>
         <button id={this.props.num} onClick={this.props.update}>{this.props.num}</button>   
      </div> 
      
      );
    }
}

export default NumKey;