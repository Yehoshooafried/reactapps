import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import NumKey from './component/NumKey';

const arr =[];

for(let i=0; i<10; i++){
    arr.push(i)
}

class NumKeyApp extends React.Component {
    constructor(props) {
        super(props);
    this.state = {a: 2}
    this.update = this.update.bind(this)
}

update(e){
 this.setState({a:this.state.a + Number(e.target.id)})   
}

    render() { 
        return ( 
            <div>
               {arr.map((e,index) =><span key={index}><NumKey update={this.update} num={index}/></span> )}
                 
                <h1>total:{this.state.a}</h1>
            </div>
         );
    }
}
 
export default NumKeyApp;