import React, { Component ,createRef} from 'react'

class Ref extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
        this.focusHandler = this.focusHandler.bind(this)
        // this.focusHandler1 = this.focusHandler1.bind(this)
    }
    // ref = createRef()
    // ref1 = createRef()
    

// createRef = element =>{
//     this.ref = element
// }

    focusHandler(){
this.ref.focus()
    }

//     focusHandler1(){
// this.ref.current.focus()
//     }

    render() { 
        return ( 

            <>
                <input ref={element => this.ref = element }  type="text" />
                {/* <input ref={this.ref1}  type="text" /> */}
                
                <button onClick={this.focusHandler}>focus</button>
                {/* <button onClick={this.focusHandler1}>focus2</button> */}
            </>
         );
    }
}
 
export default Ref;