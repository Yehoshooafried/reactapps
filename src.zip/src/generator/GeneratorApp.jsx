import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import MemeGenerator from './component/MemeGenerator';
import Header from './component/Header';


class GeneratorApp extends Component {
    constructor(props) {
        super(props);
    }
    state = {  }
    render() { 
        return ( 
            <div>
           
            <Header/>
            <MemeGenerator/>
            </div>
         );
    }
}
 
export default  GeneratorApp;