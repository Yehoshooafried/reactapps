import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import MemeGenerator from './MemeGenerator';

class Header extends Component {
    constructor(props) {
        super(props);
    }
    state = {  }
    render() { 
        return ( 
            <header>
            <img width={'100px'} height={'100px'}
                src="http://www.pngall.com/wp-content/uploads/2016/05/Trollface.png" 
                alt="Problem?"
            />
            
        </header>
         );
    }
}
 
export default Header;