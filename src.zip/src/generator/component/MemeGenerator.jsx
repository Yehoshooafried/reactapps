import React, { Component } from 'react'
import ReactDOM from 'react-dom'
// import Header from './Header';

class MemeGenerator extends Component {
    constructor(props) {
        super(props);
        this.state = {
            topText: '',
            bottomText: '',
            randomImage: "http://i.imgflip.com/1bij.jpg",
            allMemeImgs: []
        }
        this.handleChangeInput = this.handleChangeInput.bind(this)
        this.genRef = React.createRef()
        this.generatePicture = this.generatePicture.bind(this)
    }


    componentDidMount() {
        fetch("https://api.imgflip.com/get_memes")
            .then(response => response.json())
            .then(respons => {
                const { memes } = respons.data
                console.log(memes);
                this.setState({ allMemeImgs: memes })
                console.log(this.state.allMemeImgs);

            })



    }
    handleChangeInput(e) {
        const { name, value } = e.target

        this.setState({ [name]: value })
    }

    generatePicture(e) {
        e.preventDefault()
const randomPic = Math.floor(Math.random() * 101);
        this.genRef.current.src = `${this.state.allMemeImgs[(Math.floor(Math.random() * 101))].url}`
    }
    render() {
        return (
            <div>
                <form className='meme-form'>
                    <input
                        name='topText'
                        onChange={this.handleChangeInput}
                        value={this.state.topText}
                    />
                    <input
                        name='bottomText'
                        onChange={this.handleChangeInput}
                        value={this.state.bottomText} />

                    <button onClick={this.generatePicture}>Gen</button>
                    <div className='meme'>
                        <img ref={this.genRef} src={this.state.randomImage} />
                        <h2 className='top'>{this.state.topText}</h2>
                        <h2 className='bottom' >{this.state.bottomText}</h2>
                    </div>
                </form>

            </div>
        );
    }
}

export default MemeGenerator;